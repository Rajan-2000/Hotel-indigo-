indigo line HOTEL - STATIC WEBSITE SOURCE CODE

Included pages:
- index.html      Home page
- about.html      About the hotel
- rooms.html      Rooms, rates and services
- contact.html    Contact details and enquiry form
- css/style.css   Responsive styling
- js/script.js    Mobile navigation and demo form handling

HOW TO RUN
1. Extract the ZIP file.
2. Open index.html in a modern browser.
3. Navigate through the four pages using the menu.

CUSTOMIZE BEFORE PUBLISHING
- Replace indigo line Hotel with your actual hotel name.
- Update address, phone number, email and room prices in the HTML files.
- Replace the sample hotel photos (currently remote Unsplash image URLs) with your own licensed photos if preferred.
- Update the map/location details if you add a map.
- Connect the contact and booking forms to a backend, email service or booking provider. Forms currently show a demo confirmation only and do not send data or reserve rooms.
- The listed prices, amenities, address and contact details are sample content and should be verified/replaced.

TECHNOLOGY
HTML5, CSS3 and vanilla JavaScript. No framework or build step required.
